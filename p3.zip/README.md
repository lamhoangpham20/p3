# P3 Frontend Challenge

## Getting started

```
$ npm i 
$ npm run dev
```

Open up `http://localhost:3000`

