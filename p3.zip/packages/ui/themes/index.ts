import base from "./base";

import modern from "./modern";
import myTheme from "./myTheme";
import nineties from "./nineties";

export default {
  base,
  modern,
  nineties,
  myTheme
};
